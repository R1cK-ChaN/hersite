# Cynthia Liu — LinkedIn Profile Assets

Crawled from: https://sg.linkedin.com/in/cynthia-liumingyue

## Profile Summary

| Field | Value |
|-------|-------|
| Name | Cynthia Liu |
| Location | Singapore, Singapore |
| Followers | 2K |
| Connections | 500+ |
| Current Role | Management Trainee @ TPC (Tsao Pao Chee) |
| Rotation Areas | Real Estate, VC & PE |
| Education | 南洋理工大学 (Nanyang Technological University) |
| Languages | English (Professional), Chinese (Native/Bilingual) |

## About
Hi there, welcome to my page 👋
I'm Cynthia and now serving as Management Trainee @TPC…

## Folder Structure

```
cynthia-assets/
├── README.md                    ← This file
├── images/
│   ├── profile/
│   │   ├── profile-photo.*      ← LinkedIn profile picture
│   │   └── banner-singapore-skyline.*  ← Cover/banner photo
│   ├── logos/
│   │   ├── tpc-logo.*           ← TPC (Tsao Pao Chee) logo (header)
│   │   ├── tpc-company-logo.*   ← TPC logo (experience section)
│   │   ├── ntu-logo.*           ← NTU (南洋理工大学) logo
│   │   ├── google-logo.*        ← Google (certification)
│   │   ├── uc-davis-logo.*      ← UC Davis (certification)
│   │   ├── sac-logo.*           ← Securities Association of China
│   │   └── salt-light-archery-logo.*  ← Salt & Light Archery
│   └── posts/
│       ├── activity-post1-davos.*           ← Davos conversation post
│       ├── post-tpc-mtp-applications.*      ← TPC MTP recruitment
│       ├── post-davos2026-strategy.*        ← Davos 2026 strategy era
│       ├── post-cfa-level1.*                ← CFA Level I passed
│       ├── post-quiet-offering-leadership.* ← "A Quiet Offering" family business
│       ├── post-davos-wef-values.*          ← WEF values/culture
│       ├── post-tpc-house-davos.*           ← TPC House at WEF
│       ├── post-tpc-joined-announcement.*   ← Joined TPC announcement (百记 logo)
│       ├── post-cycling-140km.*             ← 140km cycling milestone
│       └── post-2025-year-end-thanks.*      ← 2025 year-end gratitude
└── text/
    ├── 01-profile-header.md     ← Name, location, headline, about
    ├── 02-experience-education.md ← Experience, certifications, languages
    └── 03-activity-posts.md     ← All visible activity/post text
```

## Licenses & Certifications

| Certification | Issuer | Date |
|--------------|--------|------|
| Archery (Recurved) | Salt & Light Archery | Mar 2025 |
| SQL for Data Science Capstone Project | UC Davis | Jan 2025 |
| Data Wrangling, Analysis and AB Testing with SQL | UC Davis | Dec 2024 |
| Google Data Analytics | Google | Dec 2024 |
| SQL for Data Science | UC Davis | Dec 2024 |
| Securities Qualification Certificate | Securities Association of China | Jul 2021 |

## Notes
- Experience details are partially hidden behind LinkedIn's login wall (shown as asterisks)
- From visible post content: role involves "Managing Director, Energy Transition" at TPC
- TPC is a fourth-generation family business (shipping → logistics → current)
- Active at World Economic Forum (Davos 2026) via TPC House
- CFA Level I passed
- Images saved in both JPEG/PNG and WebP formats
