# Experience & Education

## Experience
**TPC (Tsao Pao Chee)**
(Details hidden behind login wall - titles shown as asterisks)

From visible post content, we know:
- Management Trainee @TPC
- Rotating in Real Estate, VC & PE
- Also mentioned: "Managing Director, Energy Transition" (from a liked post about someone else joining TPC)

## Licenses & Certifications
1. **Archery (Recurved)** — Salt & Light Archery — Issued Mar 2025
2. **SQL for Data Science Capstone Project** — University of California, Davis — Issued Jan 2025 — Credential ID XOIO5AUOQ75V
3. **Data Wrangling, Analysis and AB Testing with SQL** — University of California, Davis — Issued Dec 2024 — Credential ID 6IUYQIVKDHXX
4. **Google Data Analytics** — Google — Issued Dec 2024 — Credential ID UADASAY2C0LI
5. **SQL for Data Science** — University of California, Davis — Issued Dec 2024 — Credential ID 2OC9EB9XCF3A
6. **Securities Qualification Certificate** — Securities Association of China — Issued Jul 2021

## Languages
- English — Professional working proficiency
- Chinese — Native or bilingual proficiency
