# Cynthia Liu — LinkedIn Profile Header

**Name:** Cynthia Liu
**Location:** Singapore, Singapore
**Followers:** 2K followers
**Connections:** 500+ connections
**Current Company:** TPC (Tsao Pao Chee)
**Education:** 南洋理工大学 (Nanyang Technological University)

## About
Hi there, welcome to my page 👋
I'm Cynthia and now serving as Management Trainee @TPC... (see more)
