# Cynthia Liu — LinkedIn Activity & Posts

## Recent Activity (Visible from Public Profile)

### Post 1 (Liked)
What stood out most wasn't just the location (though it certainly helped), but the depth of conversations and the trust within the room. Being a…

### Post 2 (Liked)
At #Davos2026, OCTAVE Capital felt very much at home. Our CEO May Liew, JY Chow, and Axel Tan joined Davos as part of the inaugural TPC House — not…

### Post 3 (Shared)
🙌Come join TPC MTP🙌

---

## More Activity by Cynthia

### Post 4 (Liked)
As we look ahead to 2026, we are inviting a new cohort of early-career professionals to grow with us. Our 𝗠𝗮𝗻𝗮𝗴𝗲𝗺𝗲𝗻𝘁 𝗧𝗿𝗮𝗶𝗻𝗲𝗲…

### Post 5 (Liked)
Davos 2026 reinforced something I've been feeling for a while: strategy has entered a different era. The theme — A Spirit of Dialogue — felt less…

### Post 6 (Liked)
I'm pleased to share that I've passed the CFA Level I exam! Grateful for the learning journey so far and excited to continue building deeper…

### Post 7 (Liked)
A Quiet Offering For over a century, my family has stewarded our business across generations — from shipping, to logistics, to where we stand today.…

### Post 8 (Liked)
In the following week, I'd be heading to Davos for my second time to the WEF. It's going to be an exciting time as I'd be joining the TPC House at…

### Post 9 (Liked)
I'm delighted to be joining TPC House, an accredited venue of the World Economic Forum Annual Meeting 2026, as part of a global dialogue on…

### Post 10 (Liked)
I am delighted to share that I have joined fourth-generation family business TPC (Tsao Pao Chee) Group, as Managing Director, Energy Transition. I…

### Post 11 (Liked)
Revenge cycling anyone? 140km in a week….sounds about right. Not impressive for some but a huge milestone for lazy me. Ushering in the new year…

### Post 12 (Liked)
As 2025 draws to a close, we have much to give thanks for: from a stronger-than-expected economic outlook, to the outstanding SEA Games performances…
